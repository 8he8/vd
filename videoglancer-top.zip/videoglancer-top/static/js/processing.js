/**
 * Real-time processing progress — SSE + fast polling for Colab/Cloudflare tunnels.
 */
(function () {
  "use strict";

  const STAGE_DEFS = [
    { id: "downloading", label: "Download" },
    { id: "extracting", label: "Extract" },
    { id: "deduplicating", label: "Deduplicate" },
    { id: "timestamps", label: "Timestamp" },
    { id: "compressing", label: "Compress" },
    { id: "building", label: "Build" },
    { id: "autosave", label: "Autosave" },
  ];

  const pageData = JSON.parse(document.getElementById("page-data").textContent);
  const jobId = pageData.job_id;
  const isPlaylist = Boolean(pageData.is_playlist);
  const startTime = pageData.start_time * 1000; // convert to ms

  let pollInterval = null;
  let eventSource = null;
  let sseConnected = false;
  let sseRetryCount = 0;
  const SSE_MAX_RETRIES = 5;
  let stepsBuilt = false;
  let lastPayload = "";
  let STAGES = [];
  const stageState = {};
  let lastPlaylistCompleted = -1;
  let overlayHidden = false;
  let lastBuildInfo = { format: '', current: 0, total: 0 };
  let _resetTransitions = false;
  let videoInfoShown = false;
  let cardDataReady = false;
  let timerStarted = false;
  let timerInterval = null;
  let timerStart = 0;
  let timerAccumulated = 0; // ms accumulated across playlist video segments
  let _videoDurations = []; // per-video durations saved on each playlist transition

  // Initialize STAGES, stageState, and feature flags from the pre-rendered DOM
  // so the container has its full height from first paint (no layout shift).
  var initRows = document.querySelectorAll('#procSteps .proc-row');
  initRows.forEach(function (row, i) {
    var id = row.getAttribute('data-stage');
    if (!id) return;
    var labelEl = row.querySelector('.proc-row-label');
    STAGES.push({
      id: id,
      label: labelEl ? labelEl.textContent : id,
      stepNum: i + 1,
    });
    stageState[id] = {
      status: 'pending',
      progress: 0,
      message: 'Waiting',
      metric: '',
    };
  });

  // Sync display flags from rendered stages so setStagesLayout sees them as equal
  // and returns early (no DOM rebuild needed on first paint).
  var stageIds = STAGES.map(function (s) { return s.id; });
  let showDedup = stageIds.indexOf('deduplicating') !== -1;
  let showCompress = stageIds.indexOf('compressing') !== -1;
  let showTimestamps = stageIds.indexOf('timestamps') !== -1;
  let showAutosave = stageIds.indexOf('autosave') !== -1;
  stepsBuilt = STAGES.length > 0;
  // Show YouTube card after skeleton has had a chance to paint
  // Use requestAnimationFrame so the skeleton placeholders render before real data replaces them
  if (pageData.early_video_info) {
    requestAnimationFrame(function() {
      requestAnimationFrame(function() {
        showVideoCard(pageData.early_video_info);
        videoInfoShown = true;
      });
    });
  }

  function buildStages(includeDedup, includeTimestamps, includeCompress, includeAutosave) {
    let defs = includeDedup
      ? STAGE_DEFS
      : STAGE_DEFS.filter((d) => d.id !== "deduplicating");
    if (!includeTimestamps) {
      defs = defs.filter((d) => d.id !== "timestamps");
    }
    if (!includeCompress) {
      defs = defs.filter((d) => d.id !== "compressing");
    }
    if (!includeAutosave) {
      defs = defs.filter((d) => d.id !== "autosave");
    }
    return defs.map((d, i) => ({
      id: d.id,
      label: d.label,
      stepNum: i + 1,
    }));
  }

  function resolveShowDedup(explicitFlag, stages) {
    if (explicitFlag === true) return true;
    if (explicitFlag === false) return false;
    // If user explicitly unchecked deduplication, always hide —
    // even if server sends a 'done' deduplicating stage at the end.
    if (pageData.deduplication_enabled === true) return true;
    if (pageData.deduplication_enabled === false) return false;
    if (stages?.deduplicating?.status === "skipped") return false;
    if (stages?.deduplicating) return true;
    return false;
  }

  function initStageState() {
    Object.keys(stageState).forEach((k) => delete stageState[k]);
    STAGES.forEach((s) => {
      stageState[s.id] = {
        status: "pending",
        progress: 0,
        message: "Waiting",
        metric: "",
      };
    });
    lastBuildInfo = { format: '', current: 0, total: 0 };
  }

  function setStagesLayout(includeDedup, stagesSnapshot) {
    const nextShow = includeDedup;
    if (nextShow === showDedup && stepsBuilt) return;
    showDedup = nextShow;
    STAGES = buildStages(showDedup, showTimestamps, showCompress, showAutosave);
    initStageState();
    if (stagesSnapshot) {
      applySnapshotStages(stagesSnapshot, null);
    }
    stepsBuilt = false;
    buildStepsDOM();
  }

  function formatSize(bytes) {
    if (typeof bytes !== 'number' || !isFinite(bytes) || bytes <= 0) return "0 B";
    var units = ["B", "KB", "MB", "GB", "TB"];
    var i = 0;
    var size = bytes;
    while (size >= 1024 && i < units.length - 1) {
      size /= 1024;
      i++;
    }
    return size.toFixed(i === 0 ? 0 : 1) + " " + units[i];
  }

  function metricForStage(id, details) {
    if (!details) return "";
    if (id === "downloading") {
      if (details.downloaded === "complete") return "Complete";
      // Show downloaded size / total size. When total is 0 (unknown,
      // e.g. DASH streams without file size info), show just the
      // downloaded amount so the user sees bytes growing in real-time.
      const d = typeof details.downloaded === 'number' ? details.downloaded : 0;
      const t = typeof details.total === 'number' ? details.total : 0;
      if (t > 0) return `${formatSize(d)} / ${formatSize(t)}`;
      if (d > 0) return formatSize(d);
    }
    if (id === "extracting") {
      const n = details.frames_extracted ?? 0;
      // For scene detection, only show frames extracted (no total)
      if (n) return `${n} frames`;
    }
    if (id === "deduplicating" && details.removed !== undefined) {
      return `${details.removed} removed`;
    }
    if (id === "timestamps") {
      if (details.current !== undefined) return `${details.current} / ${details.total}`;
    }
    if (id === "building") {
      // Show frame count on the right when frames are being added
      if (details.current_frame !== undefined) {
        return `${details.current_frame} / ${details.total_frames}`;
      }
    }
    if (id === "compressing") {
      if (details.current !== undefined) {
        return `${details.current} / ${details.total}`;
      }
      const msg = details.message || "";
      const m = msg.match(/Compressed (\d+)\/(\d+)/);
      if (m) return `${m[1]} / ${m[2]}`;
    }
    return "";
  }

  function mapBackendStatus(status) {
    if (status === "active") return "active";
    if (status === "done" || status === "skipped") return "done";
    if (status === "error") return "error";
    return "pending";
  }

  function dotContent(st, stepNum) {
    if (st.status === "done") return VGIcons.check;
    if (st.status === "active") return String(stepNum);
    return VGIcons.dot;
  }

  function showVideoCard(info) {
    var thumb = document.getElementById('ytCardThumb');
    var title = document.getElementById('ytCardTitle');
    var dur = document.getElementById('ytCardDuration');
    var link = document.getElementById('ytCardLink');
    if (!thumb || !title) return;

    if (info.thumbnail_url) {
      thumb.src = info.thumbnail_url;
      // Reveal the thumbnail immediately — the URL is always available from
      // the video_id (img.youtube.com/vi/ID/hqdefault.jpg), no backend call
      // needed. Title/duration skeletons stay visible until real data arrives
      // via SSE/polling (oEmbed ~200ms, or yt-dlp ~5-10s).
      document.getElementById('ytCardThumbWrap').classList.add('is-loaded');
      document.getElementById('ytCardThumbSkeleton').classList.add('is-hidden');
    }
    if (info.title) {
      title.textContent = info.title;
      document.getElementById('ytCardTitleSkeleton').classList.add('is-hidden');
      title.classList.remove('yt-card-title--empty');
    }
    if (info.duration) {
      dur.textContent = formatYoutubeDuration(info.duration);
      dur.classList.remove('yt-card-duration--empty');
      document.getElementById('ytCardDurationSkeleton').classList.add('is-hidden');
    }
    if (info.url) {
      link.href = info.url;
    }

    // When real card data renders (title or duration from yt-dlp extraction),
    // show playlist counter and reset overlay.
    if (!cardDataReady && (info.title || info.duration)) {
      cardDataReady = true;
      if (isPlaylist) {
        var plInfo = document.getElementById('playlistInfo');
        if (plInfo) plInfo.hidden = false;
      }
      // Reset overlayHidden so the next progress event can hide the steps overlay.
      // Without this, if a progress event already fired before card data arrived,
      // overlayHidden would be true and the steps overlay would never be hidden.
      overlayHidden = false;
    }
  }

  // Thumbnail reveal is handled in showVideoCard() — no event listeners needed.
  // The thumbnail skeleton is hidden immediately when thumbnail_url is available
  // from the video_id (img.youtube.com/vi/ID/hqdefault.jpg), no backend call required.

  function formatYoutubeDuration(seconds) {
    seconds = Math.round(seconds);
    var h = Math.floor(seconds / 3600);
    var m = Math.floor((seconds % 3600) / 60);
    var s = seconds % 60;
    if (h > 0) return h + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    return m + ':' + String(s).padStart(2, '0');
  }

  function setPageTitle() {
    const title = document.getElementById("page-title");
    if (!title) return;
    title.textContent = isPlaylist ? "Processing Playlist" : "Processing Video";
  }

  function hidePlaylistUI() {
    const el = document.getElementById("playlistInfo");
    if (el) el.hidden = true;
  }

  function updatePlaylistUI(playlist_info) {
    if (!isPlaylist || !playlist_info) return;
    const total = Number(playlist_info.total);

    const totalEl = document.getElementById("playlistTotal");
    const completedEl = document.getElementById("playlistCompleted");

    if (!total || total < 2) {
      // Show placeholder when count not yet known
      if (totalEl) totalEl.textContent = '\u2026';
      return;
    }

    const el = document.getElementById("playlistInfo");
    el.hidden = false;
    totalEl.textContent = total;
    const newVal = (playlist_info.completed ?? 0) + 1;

    // Animate the counter change with a subtle slide
    if (completedEl.textContent !== String(newVal)) {
      completedEl.style.transition = 'none';
      completedEl.style.opacity = '0';
      completedEl.style.transform = 'translateY(-4px)';
      completedEl.textContent = newVal;
      requestAnimationFrame(() => {
        completedEl.style.transition = 'opacity 0.2s ease, transform 0.2s ease';
        completedEl.style.opacity = '1';
        completedEl.style.transform = 'translateY(0)';
      });
    }
    setPageTitle();
  }

  function buildStepsDOM() {
    const container = document.getElementById("procSteps");
    container.innerHTML = STAGES.map((s) => {
      const st = stageState[s.id];
      return `
        <div class="proc-row" id="stage-${s.id}" data-stage="${s.id}">
          <span class="proc-row-dot" id="${s.id}-dot" aria-hidden="true">${dotContent(st, s.stepNum)}</span>
          <div class="proc-row-main">
            <div class="proc-row-head">
              <span class="proc-row-label">${s.label}</span>
              <span class="proc-row-pct" id="${s.id}-text">${st.progress}%</span>
            </div>
            <div class="proc-row-bar">
              <div class="proc-row-fill" id="${s.id}-progress"></div>
            </div>
            <div class="proc-row-foot">
              <span class="proc-row-msg" id="${s.id}-status">${st.message}</span>
              <span class="proc-row-metric" id="${s.id}-metric">${st.metric}</span>
            </div>
          </div>
        </div>`;
    }).join("");
    stepsBuilt = true;
  }

  function patchStepDOM(id) {
    const st = stageState[id];
    const row = document.getElementById(`stage-${id}`);
    if (!row) return;

    row.className = "proc-row";
    if (st.status === "active") row.classList.add("is-active");
    if (st.status === "done") row.classList.add("is-done");
    if (st.status === "error") row.classList.add("is-error");

    const dot = document.getElementById(`${id}-dot`);
    const stageDef = STAGES.find((s) => s.id === id);
    if (dot && stageDef) dot.innerHTML = dotContent(st, stageDef.stepNum);

    const fill = document.getElementById(`${id}-progress`);
    const pct = document.getElementById(`${id}-text`);
    const msg = document.getElementById(`${id}-status`);
    const metric = document.getElementById(`${id}-metric`);

    // Only update if values actually changed to prevent flickering
    if (fill) {
      const currentWidth = parseFloat(fill.style.width) || 0;
      if (Math.abs(currentWidth - st.progress) > 0.1) {
        fill.style.width = `${st.progress}%`;
      }
    }
    
    if (pct) {
      const newText = `${st.progress}%`;
      if (pct.textContent !== newText) {
        pct.textContent = newText;
      }
    }
    
    if (msg && msg.textContent !== st.message) {
      msg.textContent = st.message;
    }
    
    if (metric && metric.textContent !== st.metric) {
      metric.textContent = st.metric;
    }
  }

  function patchAllSteps() {
    if (!stepsBuilt) buildStepsDOM();
    STAGES.forEach((s) => patchStepDOM(s.id));
  }

  function applySnapshotStages(stages, refPlaylistInfo) {
    if (!stages) return;
    STAGES.forEach((s) => {
      const remote = stages[s.id];
      if (!remote) return;
      
      // Ensure progress only moves forward (monotonic increase)
      const newProgress = Math.max(0, Math.min(100, remote.progress || 0));
      const currentProgress = stageState[s.id].progress || 0;
      stageState[s.id].progress = Math.max(currentProgress, newProgress);        stageState[s.id].message = remote.message || stageState[s.id].message;
        
        // For build stage, track frame progress
        if (s.id === 'building' && remote.details) {
          if (remote.details.format) lastBuildInfo.format = remote.details.format;
          if (remote.details.current_frame !== undefined) {
            lastBuildInfo.current = remote.details.current_frame;
            lastBuildInfo.total = remote.details.total_frames;
            stageState[s.id].message = `Building ${remote.details.format} from frames...`;
          }
        }
      // Show YouTube card when video info becomes available from download stage
      // (or update the existing card with real metadata if it was already shown).
      // Apply the same stale-prefetch filter: skip video_info from events with
      // empty playlist_info when we've already transitioned past the first video.
      if (remote.details && remote.details.video_info) {
        var _hasRealPl = refPlaylistInfo && typeof refPlaylistInfo.total !== 'undefined';
        var _isStale = isPlaylist && lastPlaylistCompleted >= 0 && !_hasRealPl;
        // Same stale-video guard as applyProgress(): discard video_info from
        // events that carry a completed count lower than the current video.
        var _completed = refPlaylistInfo && refPlaylistInfo.completed;
        var _isStaleVideoInfo = isPlaylist && typeof _completed === 'number' && _completed < lastPlaylistCompleted;
        if (!_isStale && !_isStaleVideoInfo) {
          showVideoCard(remote.details.video_info);
          videoInfoShown = true;
        }
      }

      stageState[s.id].metric =
        metricForStage(s.id, remote.details) || stageState[s.id].metric;
      stageState[s.id].status = mapBackendStatus(remote.status);
      if (stageState[s.id].progress === 100 && stageState[s.id].status === "done") {
        stageState[s.id].message = "Done";
      }
    });
  }

  function _computeTimerTotal() {
    var total = 0;
    for (var i = 0; i < _videoDurations.length; i++) total += _videoDurations[i];
    total += timerAccumulated + (Date.now() - timerStart);
    return total;
  }

  function pauseTimer() {
    if (timerStarted) {
      var elapsed = Date.now() - timerStart;
      // Save this completed video's duration for the result page total
      _videoDurations.push(timerAccumulated + elapsed);
      timerAccumulated = 0; // Reset so processing page shows only current video's time
      timerStarted = false;
      if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
      }
    }
  }

  function hideStepsOverlay() {
    var overlay = document.getElementById('procStepsOverlay');
    if (overlay) {
      overlay.classList.add('is-hidden');
      overlayHidden = true;
    }
    if (!timerStarted) {
      timerStarted = true;
      timerStart = Date.now();
      var timerWrap = document.getElementById('procTimerWrap');
      if (timerWrap) timerWrap.classList.remove('is-hidden');
      updateTimer();
      timerInterval = setInterval(updateTimer, 1000);
    }
  }

  function applyProgress(data, explicitDedupFlag) {
    if (!data) return;
    const serialized = JSON.stringify(data);
    if (serialized === lastPayload) return;
    lastPayload = serialized;

    const { stage, message, playlist_info, stages } = data;

    // ── Playlist transition: MUST run BEFORE rendering video_info or stages ──
    // to prevent stale card data (title/duration from a previous video or from
    // a late-arriving prefetch event) from flashing on screen.
    if (isPlaylist) {
      const completed = playlist_info?.completed ?? 0;
      // Only apply the stale-guard when playlist_info actually carries a
      // completed count. Non-playlist-transition events (complete, error,
      // cancelled) have an empty playlist_info fallback from app.py's
      // progress_callback, and must NOT be treated as stale.
      const hasCompleted = playlist_info && 'completed' in playlist_info;

      // Only transition FORWARD — stale/delayed SSE events from the tunnel
      // must not re-trigger the reset with an older completed count.
      if (completed > lastPlaylistCompleted && lastPlaylistCompleted !== -1) {
        // Disable progress bar CSS transitions during reset so the bars
        // snap to 0% instantly instead of animating backwards.
        _resetTransitions = true;
        document.querySelectorAll('.proc-row-fill').forEach(function (el) {
          el.style.transition = 'none';
        });

        initStageState();
        videoInfoShown = false;
        cardDataReady = false;
        // Reset YouTube card to skeleton state (don't hide it entirely)
        // so the user always sees a card shape during transitions,
        // not a blank gap.
        const ytCard = document.getElementById('ytCard');
        if (ytCard) {
          ytCard.hidden = false;
          // Show all skeleton placeholders
          document.getElementById('ytCardThumbWrap').classList.remove('is-loaded');
          document.getElementById('ytCardThumbSkeleton').classList.remove('is-hidden');
          document.getElementById('ytCardTitleSkeleton').classList.remove('is-hidden');
          document.getElementById('ytCardDurationSkeleton').classList.remove('is-hidden');
          // Clear old content
          document.getElementById('ytCardThumb').src = '';
          document.getElementById('ytCardTitle').textContent = '';
          document.getElementById('ytCardTitle').classList.add('yt-card-title--empty');
          document.getElementById('ytCardDuration').textContent = '';
          document.getElementById('ytCardDuration').classList.add('yt-card-duration--empty');
        }
        // Pause the processing timer (don't count gap between videos)
        pauseTimer();
        // Show thumbnail instantly from video_id (img.youtube.com/vi/ID/hqdefault.jpg)
        // Same progressive rendering as single videos: thumbnail appears on first paint,
        // then oEmbed fills in title (~200ms), then yt-dlp fills in duration (~5-10s).
        if (playlist_info && playlist_info.video_id) {
          var _thumbUrl = 'https://img.youtube.com/vi/' + playlist_info.video_id + '/hqdefault.jpg';
          document.getElementById('ytCardThumb').src = _thumbUrl;
          document.getElementById('ytCardThumbWrap').classList.add('is-loaded');
          document.getElementById('ytCardThumbSkeleton').classList.add('is-hidden');
          // Set link to the YouTube video so the card is clickable immediately
          var _link = document.getElementById('ytCardLink');
          if (_link) _link.href = 'https://www.youtube.com/watch?v=' + playlist_info.video_id;
        }
        // Show steps "Starting..." overlay for new video
        const stepsOverlay = document.getElementById('procStepsOverlay');
        if (stepsOverlay) stepsOverlay.classList.remove('is-hidden');
        overlayHidden = false;
      } else if (hasCompleted && completed < lastPlaylistCompleted) {
        // Stale/delayed event from tunnel with an older completed count —
        // discard entirely to prevent the video counter from going backward.
        return;
      }

      // Fill title from oEmbed data bundled with the playlist transition event —
      // runs OUTSIDE the forward-transition guard so it applies even when
      // Cloudflare buffers and re-delivers events with the same completed count.
      if (playlist_info && playlist_info.title) {
        document.getElementById('ytCardTitle').textContent = playlist_info.title;
        document.getElementById('ytCardTitle').classList.remove('yt-card-title--empty');
        document.getElementById('ytCardTitleSkeleton').classList.add('is-hidden');
      }

      lastPlaylistCompleted = Math.max(lastPlaylistCompleted, completed);
      updatePlaylistUI(playlist_info);
    }

    // Render card if metadata is available (piped via early_metadata_callback
    // from yt-dlp's internal extraction, or from prefetched cache).
    // Placed AFTER the playlist reset so stale data from a previous video
    // is already cleared before new data is rendered.
    if (data.details && data.details.video_info) {
      // Skip stale video_info from _prefetch_early_meta when we've already
      // transitioned past the first video. The prefetch event has an empty
      // playlist_info ({}) while pipeline events for playlist videos inherit
      // the real playlist_info (with total/completed) from the last transition.
      // Without this filter, a late-arriving prefetch event would overwrite
      // the current video's card with the first video's title and duration.
      var hasRealPlaylistInfo = playlist_info && typeof playlist_info.total !== 'undefined';
      var isStalePrefetch = isPlaylist && lastPlaylistCompleted >= 0 && !hasRealPlaylistInfo;
      // Also skip stale video_info from delayed SSE events belonging to a
      // previous video. Events emitted during video N carry
      // playlist_info.completed = N-1 (from prev_pl at the time of emission),
      // while events for video N+1 carry completed = N (updated by the
      // playlist transition). Through a tunnel, events arrive out of order,
      // so a delayed video_N event with completed = N-1 would overwrite the
      // skeleton with stale data if not filtered.
      var _completed = playlist_info && playlist_info.completed;
      var _isStaleVideo = isPlaylist && typeof _completed === 'number' && _completed < lastPlaylistCompleted;
      if (!isStalePrefetch && !_isStaleVideo) {
        showVideoCard(data.details.video_info);
        videoInfoShown = true;
      }
    }

    // Hide the "Starting..." overlay on the steps card once the first real
    // backend stage begins.
    if (!overlayHidden && stage && stage !== 'initializing' && stage !== 'playlist') {
      hideStepsOverlay();
    }

    setStagesLayout(resolveShowDedup(explicitDedupFlag, stages), stages);

    if (stages) {
      applySnapshotStages(stages, playlist_info);
    }

    patchAllSteps();

    // Re-enable progress bar transitions after a playlist reset.
    // Must run after patchAllSteps() has set widths to 0% (no animated rewind).
    if (_resetTransitions) {
      _resetTransitions = false;
      requestAnimationFrame(function () {
        document.querySelectorAll('.proc-row-fill').forEach(function (el) {
          if (el.style.transition === 'none') {
            el.style.transition = '';
          }
        });
      });
    }

    if (stage === "complete") {
      STAGES.forEach((s) => {
        stageState[s.id].status = "done";
        stageState[s.id].progress = 100;
        stageState[s.id].message = "Done";
      });
      patchAllSteps();
      if (eventSource) eventSource.close();
      if (pollInterval) clearInterval(pollInterval);
      if (timerInterval) clearInterval(timerInterval);
      // Capture the exact final timer value so the result page shows the same
      // duration as the processing page (not inflated by redirect time).
      // The total is the sum of all per-video durations (from pauseTimer saves)
      // plus the current segment, so the result page shows the playlist's sum.
      const finalMs = _computeTimerTotal();
      try { sessionStorage.setItem('_vg_final_duration', String(finalMs)); } catch (e) {}
      setTimeout(() => {
        window.location.href = `/result/${jobId}`;
      }, 700);
    }

    if (stage === "error") {
      const active = STAGES.find((s) => stageState[s.id].status === "active");
      if (active) {
        stageState[active.id].status = "error";
        stageState[active.id].message = message || "Failed";
        patchStepDOM(active.id);
      }
      if (eventSource) eventSource.close();
      if (pollInterval) clearInterval(pollInterval);
      if (timerInterval) clearInterval(timerInterval);
      setTimeout(() => {
        window.location.href = `/error?error=${encodeURIComponent(message || "Processing failed")}&job_id=${jobId}`;
      }, 1200);
    }

    // Show toast when autosave completes (files saved to Google Drive on Colab)
    if (stage === "autosave" && stages?.autosave?.status === "done") {
      if (typeof window.showToast === "function" && pageData.is_colab) {
        window.showToast("Files saved to Google Drive", "ok");
      }
    }

    if (stage === "cancelled") {
      if (eventSource) eventSource.close();
      if (pollInterval) clearInterval(pollInterval);
      if (timerInterval) clearInterval(timerInterval);
      window.location.href = '/cancelled';
    }
  }

  function pollStatus() {
    fetch(`/status/${jobId}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.deduplication_enabled !== undefined) {
          pageData.deduplication_enabled = data.deduplication_enabled;
        }
        if (data.progress) {
          applyProgress(data.progress, data.deduplication_enabled);
        }
        if (data.status === "completed") {
          // Capture the timer before redirecting — polling can beat the SSE
          // 'complete' event, and without this the result page would fall back
          // to the server's Math.round() value instead of the precise frontend timer.
          // The total is the sum of all per-video durations (from pauseTimer saves)
          // plus the current segment, so the result page shows the playlist's sum.
          const finalMs = _computeTimerTotal();
          try { sessionStorage.setItem('_vg_final_duration', String(finalMs)); } catch (e) {}
          window.location.href = `/result/${jobId}`;
        }
        if (data.status === "cancelled") {
          window.location.href = '/cancelled';
        }
      })
      .catch(() => {});
  }

  window.cancelProcessing = async function () {
    const confirmed = await showConfirmDialog('Cancel processing?', 'Your progress will be lost and you will need to start over.');
    if (!confirmed) return;
    
    // Close SSE, polling, and timer immediately so the UI stops updating
    if (eventSource) { eventSource.close(); eventSource = null; }
    if (pollInterval) { clearInterval(pollInterval); pollInterval = null; }
    if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
    timerStarted = false;
    
    const btn = document.getElementById("cancel-btn");
    btn.disabled = true;
    btn.textContent = "Cancelling…";
    
    // Fire cancel request but don't wait — redirect right away.
    // Use sendBeacon so the request reliably completes even during page navigation.
    navigator.sendBeacon(`/cancel/${jobId}`);
    window.location.href = '/cancelled';
  };

  function formatElapsed(ms) {
    const totalSec = Math.floor(ms / 1000);
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return `${min}:${sec.toString().padStart(2, '0')}`;
  }

  function updateTimer() {
    if (!timerStarted) return;
    const el = document.getElementById('procTimer');
    if (!el) return;
    const totalMs = timerAccumulated + (Date.now() - timerStart);
    el.textContent = formatElapsed(totalMs);
  }

  setPageTitle();
  // Don't show playlist counter yet — wait until card data renders
  // so it appears alongside the YouTube card info.
  // Keep it hidden initially by not removing the hidden attribute.
  if (isPlaylist) {
    document.getElementById("playlistCompleted").textContent = "1";
    if (pageData.playlist_total > 1) {
      document.getElementById("playlistTotal").textContent = pageData.playlist_total;
    }
  } else {
    hidePlaylistUI();
  }

  const initStages = pageData.initial_progress?.stages;
  setStagesLayout(
    resolveShowDedup(pageData.deduplication_enabled, initStages),
    initStages
  );

  if (pageData.initial_progress) {
    applyProgress(pageData.initial_progress, pageData.deduplication_enabled);
    lastPayload = "";
  }

  function setPollInterval() {
    if (pollInterval) clearInterval(pollInterval);
    var ms = sseConnected ? 2000 : 300;
    pollInterval = setInterval(pollStatus, ms);
  }

  function connectSSE() {
    eventSource = new EventSource(`/progress/${jobId}`);
    eventSource.onmessage = function (e) {
      sseConnected = true;
      sseRetryCount = 0;
      setPollInterval();
      try {
        applyProgress(JSON.parse(e.data));
      } catch (err) {
        console.error(err);
      }
    };
    eventSource.onerror = function () {
      sseConnected = false;
      setPollInterval();
      if (eventSource) {
        eventSource.close();
        eventSource = null;
      }
      if (sseRetryCount < SSE_MAX_RETRIES) {
        sseRetryCount++;
        setTimeout(connectSSE, 2000);
      }
    };
  }

  // Defer first poll AND SSE connection by one frame so the browser paints the
  // initial "Starting..." overlay before any progress event can hide it.
  // Without this, the SSE first event (which yields the current backend state)
  // arrives before paint, hiding the overlay immediately if the backend has
  // already progressed past 'initializing' (which it often has).
  requestAnimationFrame(function () {
    pollStatus();
    setPollInterval();
    connectSSE();
  });
})();
