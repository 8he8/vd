"""
File management module for directory setup and cleanup.
Extracted from the original Colab notebook.
"""

import os
import json
import shutil
import logging

logger = logging.getLogger(__name__)

META_FILENAME = 'outputs_meta.json'
ZIP_SUFFIX = 'Videoglancer all converted files -- '


def is_internal_output_file(filename):
    """Files that must not appear in Converted Files UI."""
    return filename == META_FILENAME or filename.startswith('Videoglancer all converted files -- ')


def list_job_directories(root_job_id=None):
    """
    List output directories. With flat structure, returns the root OUTPUT_DIR only.
    """
    from config import OUTPUT_DIR
    if not os.path.exists(OUTPUT_DIR):
        return []
    return [(root_job_id or 'outputs', OUTPUT_DIR)]


def find_output_file(root_job_id, filename):
    """Resolve filename to (storage_job_id, absolute_path).
    First checks directly in OUTPUT_DIR, then checks subdirectories
    (e.g., playlist folders). Also handles relative paths with subdirectory prefix."""
    from config import OUTPUT_DIR

    # Check if filename already contains a subdirectory path
    file_path = os.path.join(OUTPUT_DIR, filename)
    if os.path.isfile(file_path):
        return root_job_id or 'outputs', file_path

    # Search subdirectories for the basename (for legacy links with just filename)
    basename = os.path.basename(filename)
    for entry in sorted(os.listdir(OUTPUT_DIR)):
        subpath = os.path.join(OUTPUT_DIR, entry)
        if os.path.isdir(subpath):
            candidate = os.path.join(subpath, basename)
            if os.path.isfile(candidate):
                return root_job_id or 'outputs', candidate

    return None, None


def iter_output_files(root_job_id=None):
    """Yield (storage_job_id, job_path, filename, filepath) for convertible outputs.
    Scans OUTPUT_DIR recursively (files at root + files in playlist subdirectories).
    For files in subdirectories, the yielded filename includes the relative subdirectory path."""
    from config import OUTPUT_DIR

    if not os.path.exists(OUTPUT_DIR):
        return

    for entry in sorted(os.listdir(OUTPUT_DIR)):
        filepath = os.path.join(OUTPUT_DIR, entry)
        if os.path.isfile(filepath):
            if is_internal_output_file(entry):
                continue
            yield root_job_id or 'outputs', OUTPUT_DIR, entry, filepath
        elif os.path.isdir(filepath):
            # Playlist subdirectory — yield files inside with relative path prefix
            subdir_name = entry
            for filename in sorted(os.listdir(filepath)):
                sub_filepath = os.path.join(filepath, filename)
                if not os.path.isfile(sub_filepath):
                    continue
                if is_internal_output_file(filename):
                    continue
                # Include subdir prefix so download route can resolve the path.
                # Use forward slash for cross-platform URL/zip compatibility.
                rel_filename = subdir_name + '/' + filename
                yield root_job_id or 'outputs', filepath, rel_filename, sub_filepath


def save_output_meta(job_output_dir, filename, video_title=None, job_id=None):
    """Persist per-output metadata (title, job id) to DATA_DIR/outputs_meta.json.
    DATA_DIR is always local (never on Google Drive), so the meta file stays out of Drive."""
    from config import DATA_DIR
    os.makedirs(DATA_DIR, exist_ok=True)
    meta_path = os.path.join(DATA_DIR, META_FILENAME)
    meta = {}
    if os.path.exists(meta_path):
        try:
            with open(meta_path, 'r', encoding='utf-8') as f:
                meta = json.load(f)
        except (json.JSONDecodeError, OSError):
            meta = {}
    entry = meta.get(filename, {})
    if video_title is not None:
        entry['video_title'] = video_title
    if job_id is not None:
        entry['job_id'] = job_id
    meta[filename] = entry
    with open(meta_path, 'w', encoding='utf-8') as f:
        json.dump(meta, f, ensure_ascii=False)


def load_output_meta(job_dir):
    """Load outputs_meta.json from DATA_DIR (always local, never on Drive)."""
    from config import DATA_DIR
    meta_path = os.path.join(DATA_DIR, META_FILENAME)
    if not os.path.exists(meta_path):
        return {}
    try:
        with open(meta_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def setup_directories():
    """Create working directory structure."""
    logger.info("\n" + "=" * 70 + "\nSETTING UP DIRECTORY STRUCTURE\n" + "=" * 70)

    from config import WORK_DIR, OUTPUT_DIR, FRAMES_DIR

    if os.path.exists(FRAMES_DIR):
        logger.info(f"Clearing existing frames in: {FRAMES_DIR}/")
        shutil.rmtree(FRAMES_DIR)
    os.makedirs(FRAMES_DIR, exist_ok=True)

    for directory in [WORK_DIR, OUTPUT_DIR]:
        if not os.path.exists(directory):
            os.makedirs(directory)
            logger.info(f"Created: {directory}/")

    logger.info(f"\nDirectory structure:")
    logger.info(f"videoglancer/")
    logger.info(f"|- temp/frames/ (extracted image frames)")
    logger.info(f"|- outputs/ (final PDF/PPT files)")
    logger.info("=" * 70)

    return WORK_DIR, OUTPUT_DIR, FRAMES_DIR


def cleanup_temp_files(temp_video_frames_folder, temp_download_dir, local_download_file):
    """
    Clean up temporary files after processing.
    
    Args:
        temp_video_frames_folder: Path to temporary frames folder
        temp_download_dir: Path to temporary download directory
        local_download_file: Path to downloaded video file
    """
    logger.info("\n" + "=" * 70 + "\nCLEANING UP\n" + "=" * 70)
    
    if temp_video_frames_folder and os.path.exists(temp_video_frames_folder):
        logger.info(f"Removing temporary frames...")
        shutil.rmtree(temp_video_frames_folder)

    if local_download_file and os.path.exists(local_download_file):
        logger.info(f"Removing temporary downloaded video file: {local_download_file}")
        os.remove(local_download_file)
        if temp_download_dir and os.path.exists(temp_download_dir) and not os.listdir(temp_download_dir):
            shutil.rmtree(temp_download_dir)

    logger.info("=" * 70)


def setup_job_directories(job_id):
    """
    Create directories for a specific job.
    Output files go directly into OUTPUT_DIR (flat structure), not in job subfolder.
    
    Args:
        job_id: Unique job identifier
    
    Returns:
        Tuple of (job_output_dir, job_frames_dir, job_temp_dir)
    """
    from config import OUTPUT_DIR, FRAMES_DIR, TEMP_DOWNLOAD_DIR
    
    # Flat output — files go directly in OUTPUT_DIR
    job_output_dir = OUTPUT_DIR
    job_frames_dir = os.path.join(FRAMES_DIR, job_id)
    job_temp_dir = os.path.join(TEMP_DOWNLOAD_DIR, job_id)
    
    os.makedirs(job_frames_dir, exist_ok=True)
    os.makedirs(job_temp_dir, exist_ok=True)
    
    return job_output_dir, job_frames_dir, job_temp_dir


def cleanup_job_directories(job_id):
    """
    Clean up directories for a specific job.
    
    Args:
        job_id: Unique job identifier
    """
    from config import FRAMES_DIR, TEMP_DOWNLOAD_DIR
    
    job_frames_dir = os.path.join(FRAMES_DIR, job_id)
    job_temp_dir = os.path.join(TEMP_DOWNLOAD_DIR, job_id)
    
    if os.path.exists(job_frames_dir):
        shutil.rmtree(job_frames_dir)
    
    if os.path.exists(job_temp_dir):
        shutil.rmtree(job_temp_dir)
