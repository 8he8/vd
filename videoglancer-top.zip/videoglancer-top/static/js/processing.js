/**
 * Real-time processing progress — SSE + fast polling for Colab/Cloudflare tunnels.
 */
(function () {
  "use strict";

  const STAGE_DEFS = [
    { id: "downloading", label: "Download" },
    { id: "extracting", label: "Extract" },
    { id: "deduplicating", label: "Deduplicate" },
    { id: "timestamps", label: "Timestamp" },
    { id: "compressing", label: "Compress" },
    { id: "building", label: "Build" },
    { id: "autosave", label: "Autosave" },
  ];

  const pageData = JSON.parse(document.getElementById("page-data").textContent);
  const jobId = pageData.job_id;
  const isPlaylist = Boolean(pageData.is_playlist);
  const startTime = pageData.start_time * 1000; // convert to ms

  let pollInterval = null;
  let eventSource = null;
  let stepsBuilt = false;
  let lastPayload = "";
  let showDedup = pageData.deduplication_enabled === true;
  let showCompress = pageData.compress_enabled === true;
  let STAGES = [];
  const stageState = {};
  let lastPlaylistCompleted = -1;
  let overlayHidden = false;
  let lastBuildInfo = { format: '', current: 0, total: 0 };
  let videoInfoShown = false;
  let cardDataReady = false;
  let timerStarted = false;
  let timerInterval = null;
  let timerStart = 0;
  let timerAccumulated = 0; // ms accumulated across playlist video segments
  // Show YouTube card after skeleton has had a chance to paint
  // Use requestAnimationFrame so the skeleton placeholders render before real data replaces them
  if (pageData.early_video_info) {
    requestAnimationFrame(function() {
      requestAnimationFrame(function() {
        showVideoCard(pageData.early_video_info);
        videoInfoShown = true;
      });
    });
  }

  let showTimestamps = pageData.timestamp_enabled !== false;
  let showAutosave = pageData.autosave_enabled === true;

  function buildStages(includeDedup, includeTimestamps, includeCompress, includeAutosave) {
    let defs = includeDedup
      ? STAGE_DEFS
      : STAGE_DEFS.filter((d) => d.id !== "deduplicating");
    if (!includeTimestamps) {
      defs = defs.filter((d) => d.id !== "timestamps");
    }
    if (!includeCompress) {
      defs = defs.filter((d) => d.id !== "compressing");
    }
    if (!includeAutosave) {
      defs = defs.filter((d) => d.id !== "autosave");
    }
    return defs.map((d, i) => ({
      id: d.id,
      label: d.label,
      stepNum: i + 1,
    }));
  }

  function resolveShowDedup(explicitFlag, stages) {
    if (explicitFlag === true) return true;
    if (explicitFlag === false) return false;
    // If user explicitly unchecked deduplication, always hide —
    // even if server sends a 'done' deduplicating stage at the end.
    if (pageData.deduplication_enabled === true) return true;
    if (pageData.deduplication_enabled === false) return false;
    if (stages?.deduplicating?.status === "skipped") return false;
    if (stages?.deduplicating) return true;
    return false;
  }

  function initStageState() {
    Object.keys(stageState).forEach((k) => delete stageState[k]);
    STAGES.forEach((s) => {
      stageState[s.id] = {
        status: "pending",
        progress: 0,
        message: "Waiting",
        metric: "",
      };
    });
    lastBuildInfo = { format: '', current: 0, total: 0 };
  }

  function setStagesLayout(includeDedup, stagesSnapshot) {
    const nextShow = includeDedup;
    if (nextShow === showDedup && stepsBuilt) return;
    showDedup = nextShow;
    STAGES = buildStages(showDedup, showTimestamps, showCompress, showAutosave);
    initStageState();
    if (stagesSnapshot) {
      applySnapshotStages(stagesSnapshot);
    }
    stepsBuilt = false;
    buildStepsDOM();
  }

  function formatSize(bytes) {
    if (typeof bytes !== 'number' || !isFinite(bytes) || bytes <= 0) return "0 B";
    var units = ["B", "KB", "MB", "GB", "TB"];
    var i = 0;
    var size = bytes;
    while (size >= 1024 && i < units.length - 1) {
      size /= 1024;
      i++;
    }
    return size.toFixed(i === 0 ? 0 : 1) + " " + units[i];
  }

  function metricForStage(id, details) {
    if (!details) return "";
    if (id === "downloading") {
      if (details.downloaded === "complete") return "Complete";
      // Show downloaded size / total size. When total is 0 (unknown,
      // e.g. DASH streams without file size info), show just the
      // downloaded amount so the user sees bytes growing in real-time.
      const d = typeof details.downloaded === 'number' ? details.downloaded : 0;
      const t = typeof details.total === 'number' ? details.total : 0;
      if (t > 0) return `${formatSize(d)} / ${formatSize(t)}`;
      if (d > 0) return formatSize(d);
    }
    if (id === "extracting") {
      const n = details.frames_extracted ?? 0;
      // For scene detection, only show frames extracted (no total)
      if (n) return `${n} frames`;
    }
    if (id === "deduplicating" && details.removed !== undefined) {
      return `${details.removed} removed`;
    }
    if (id === "timestamps") {
      if (details.current !== undefined) return `${details.current} / ${details.total}`;
    }
    if (id === "building") {
      // Show frame count on the right when frames are being added
      if (details.current_frame !== undefined) {
        return `${details.current_frame} / ${details.total_frames}`;
      }
    }
    if (id === "compressing") {
      if (details.current !== undefined) {
        return `${details.current} / ${details.total}`;
      }
      const msg = details.message || "";
      const m = msg.match(/Compressed (\d+)\/(\d+)/);
      if (m) return `${m[1]} / ${m[2]}`;
    }
    return "";
  }

  function mapBackendStatus(status) {
    if (status === "active") return "active";
    if (status === "done" || status === "skipped") return "done";
    if (status === "error") return "error";
    return "pending";
  }

  function dotContent(st, stepNum) {
    if (st.status === "done") return VGIcons.check;
    if (st.status === "active") return String(stepNum);
    return VGIcons.dot;
  }

  function showVideoCard(info) {
    var thumb = document.getElementById('ytCardThumb');
    var title = document.getElementById('ytCardTitle');
    var dur = document.getElementById('ytCardDuration');
    var link = document.getElementById('ytCardLink');
    if (!thumb || !title) return;

    // Always set the thumbnail src early so it starts loading in the background,
    // but don't reveal it (add is-loaded) until we also have title/duration.
    if (info.thumbnail_url) {
      thumb.src = info.thumbnail_url;
    }
    if (info.title) {
      title.textContent = info.title;
      document.getElementById('ytCardTitleSkeleton').classList.add('is-hidden');
      title.classList.remove('yt-card-title--empty');
    }
    if (info.duration) {
      dur.textContent = formatYoutubeDuration(info.duration);
      dur.classList.remove('yt-card-duration--empty');
      document.getElementById('ytCardDurationSkeleton').classList.add('is-hidden');
    }
    if (info.url) {
      link.href = info.url;
    }

    // When real card data renders (title or duration from yt-dlp extraction),
    // reveal thumbnail and show playlist counter.
    // thumbnail_url alone isn't enough — it can be derived from video_id,
    // so we wait until title or duration arrives from the background thread.
    if (!cardDataReady && (info.title || info.duration)) {
      cardDataReady = true;
      // Now reveal the thumbnail (it was already loading in background)
      document.getElementById('ytCardThumbWrap').classList.add('is-loaded');
      document.getElementById('ytCardThumbSkeleton').classList.add('is-hidden');
      // Show playlist counter alongside the YouTube card data
      if (isPlaylist) {
        var plInfo = document.getElementById('playlistInfo');
        if (plInfo) plInfo.hidden = false;
      }
      // Reset overlayHidden so the next progress event can hide the steps overlay.
      // Without this, if a progress event already fired before card data arrived,
      // overlayHidden would be true and the steps overlay would never be hidden.
      overlayHidden = false;
    }
  }

  function hideCardSkeletons() {
    // Only reveal the thumbnail if card data (title/duration) is already ready.
    // Otherwise, the thumbnail would appear before title+duration, breaking the
    // simultaneous reveal. The reveal happens in showVideoCard when cardDataReady.
    if (!cardDataReady) return;
    document.getElementById('ytCardThumbSkeleton').classList.add('is-hidden');
    document.getElementById('ytCardThumbWrap').classList.add('is-loaded');
  }

  // When thumbnail loads, hide the skeleton
  var thumbEl = document.getElementById('ytCardThumb');
  if (thumbEl) {
    thumbEl.addEventListener('load', hideCardSkeletons);
    thumbEl.addEventListener('error', hideCardSkeletons);
    // Only hide skeletons if a real src was set (not the initial empty src="").
    // Browsers consider empty src as "complete", which would kill the skeleton pre-paint.
    if (thumbEl.complete && thumbEl.getAttribute('src')) hideCardSkeletons();
  }

  function formatYoutubeDuration(seconds) {
    seconds = Math.round(seconds);
    var h = Math.floor(seconds / 3600);
    var m = Math.floor((seconds % 3600) / 60);
    var s = seconds % 60;
    if (h > 0) return h + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    return m + ':' + String(s).padStart(2, '0');
  }

  function setPageTitle() {
    const title = document.getElementById("page-title");
    if (!title) return;
    title.textContent = isPlaylist ? "Processing Playlist" : "Processing Video";
  }

  function hidePlaylistUI() {
    const el = document.getElementById("playlistInfo");
    if (el) el.hidden = true;
  }

  function updatePlaylistUI(playlist_info) {
    if (!isPlaylist || !playlist_info) return;
    const total = Number(playlist_info.total);

    const totalEl = document.getElementById("playlistTotal");
    const completedEl = document.getElementById("playlistCompleted");

    if (!total || total < 2) {
      // Show placeholder when count not yet known
      if (totalEl) totalEl.textContent = '\u2026';
      return;
    }

    const el = document.getElementById("playlistInfo");
    el.hidden = false;
    totalEl.textContent = total;
    const newVal = (playlist_info.completed ?? 0) + 1;

    // Animate the counter change with a subtle slide
    if (completedEl.textContent !== String(newVal)) {
      completedEl.style.transition = 'none';
      completedEl.style.opacity = '0';
      completedEl.style.transform = 'translateY(-4px)';
      completedEl.textContent = newVal;
      requestAnimationFrame(() => {
        completedEl.style.transition = 'opacity 0.2s ease, transform 0.2s ease';
        completedEl.style.opacity = '1';
        completedEl.style.transform = 'translateY(0)';
      });
    }
    setPageTitle();
  }

  function buildStepsDOM() {
    const container = document.getElementById("procSteps");
    container.innerHTML = STAGES.map((s) => {
      const st = stageState[s.id];
      return `
        <div class="proc-row" id="stage-${s.id}" data-stage="${s.id}">
          <span class="proc-row-dot" id="${s.id}-dot" aria-hidden="true">${dotContent(st, s.stepNum)}</span>
          <div class="proc-row-main">
            <div class="proc-row-head">
              <span class="proc-row-label">${s.label}</span>
              <span class="proc-row-pct" id="${s.id}-text">${st.progress}%</span>
            </div>
            <div class="proc-row-bar">
              <div class="proc-row-fill" id="${s.id}-progress"></div>
            </div>
            <div class="proc-row-foot">
              <span class="proc-row-msg" id="${s.id}-status">${st.message}</span>
              <span class="proc-row-metric" id="${s.id}-metric">${st.metric}</span>
            </div>
          </div>
        </div>`;
    }).join("");
    stepsBuilt = true;
  }

  function patchStepDOM(id) {
    const st = stageState[id];
    const row = document.getElementById(`stage-${id}`);
    if (!row) return;

    row.className = "proc-row";
    if (st.status === "active") row.classList.add("is-active");
    if (st.status === "done") row.classList.add("is-done");
    if (st.status === "error") row.classList.add("is-error");

    const dot = document.getElementById(`${id}-dot`);
    const stageDef = STAGES.find((s) => s.id === id);
    if (dot && stageDef) dot.innerHTML = dotContent(st, stageDef.stepNum);

    const fill = document.getElementById(`${id}-progress`);
    const pct = document.getElementById(`${id}-text`);
    const msg = document.getElementById(`${id}-status`);
    const metric = document.getElementById(`${id}-metric`);

    // Only update if values actually changed to prevent flickering
    if (fill) {
      const currentWidth = parseFloat(fill.style.width) || 0;
      if (Math.abs(currentWidth - st.progress) > 0.1) {
        fill.style.width = `${st.progress}%`;
      }
    }
    
    if (pct) {
      const newText = `${st.progress}%`;
      if (pct.textContent !== newText) {
        pct.textContent = newText;
      }
    }
    
    if (msg && msg.textContent !== st.message) {
      msg.textContent = st.message;
    }
    
    if (metric && metric.textContent !== st.metric) {
      metric.textContent = st.metric;
    }
  }

  function patchAllSteps() {
    if (!stepsBuilt) buildStepsDOM();
    STAGES.forEach((s) => patchStepDOM(s.id));
  }

  function applySnapshotStages(stages) {
    if (!stages) return;
    STAGES.forEach((s) => {
      const remote = stages[s.id];
      if (!remote) return;
      
      // Ensure progress only moves forward (monotonic increase)
      const newProgress = Math.max(0, Math.min(100, remote.progress || 0));
      const currentProgress = stageState[s.id].progress || 0;
      stageState[s.id].progress = Math.max(currentProgress, newProgress);        stageState[s.id].message = remote.message || stageState[s.id].message;
        
        // For build stage, track frame progress
        if (s.id === 'building' && remote.details) {
          if (remote.details.format) lastBuildInfo.format = remote.details.format;
          if (remote.details.current_frame !== undefined) {
            lastBuildInfo.current = remote.details.current_frame;
            lastBuildInfo.total = remote.details.total_frames;
            stageState[s.id].message = `Building ${remote.details.format} from frames...`;
          }
        }
      // Show YouTube card when video info becomes available from download stage
      // (or update the existing card with real metadata if it was already shown)
      if (remote.details && remote.details.video_info) {
        showVideoCard(remote.details.video_info);
        videoInfoShown = true;
      }

      stageState[s.id].metric =
        metricForStage(s.id, remote.details) || stageState[s.id].metric;
      stageState[s.id].status = mapBackendStatus(remote.status);
      if (stageState[s.id].progress === 100 && stageState[s.id].status === "done") {
        stageState[s.id].message = "Done";
      }
    });
  }

  function pauseTimer() {
    if (timerStarted) {
      timerAccumulated += Date.now() - timerStart;
      timerStarted = false;
      if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
      }
    }
  }

  function hideStepsOverlay() {
    var overlay = document.getElementById('procStepsOverlay');
    if (overlay) {
      overlay.classList.add('is-hidden');
      overlayHidden = true;
    }
    if (!timerStarted) {
      timerStarted = true;
      timerStart = Date.now();
      var timerWrap = document.getElementById('procTimerWrap');
      if (timerWrap) timerWrap.classList.remove('is-hidden');
      updateTimer();
      timerInterval = setInterval(updateTimer, 1000);
    }
  }

  function applyProgress(data, explicitDedupFlag) {
    if (!data) return;
    const serialized = JSON.stringify(data);
    if (serialized === lastPayload) return;
    lastPayload = serialized;

    const { stage, message, playlist_info, stages } = data;

    // Render card if metadata is available (piped via early_metadata_callback
    // from yt-dlp's internal extraction, or from prefetched cache).
    if (data.details && data.details.video_info) {
      showVideoCard(data.details.video_info);
      videoInfoShown = true;
    }

    // Hide the "Starting..." overlay on the steps card once the first real
    // backend stage begins.
    if (!overlayHidden && stage && stage !== 'initializing' && stage !== 'playlist') {
      hideStepsOverlay();
    }

    setStagesLayout(resolveShowDedup(explicitDedupFlag, stages), stages);

    if (isPlaylist) {
      const completed = playlist_info?.completed ?? 0;
      // When completed count increments, a new playlist video has started —
      // reset all stages to pending so leftover steps from the previous video
      // don't linger (e.g. extracting/building at 100% from the prior video).
      // Also reset overlay so "Starting..." appears for each new video.
      if (completed !== lastPlaylistCompleted && lastPlaylistCompleted !== -1) {
        initStageState();
        videoInfoShown = false;
        cardDataReady = false;
        // Reset YouTube card to skeleton state (don't hide it entirely)
        // so the user always sees a card shape during transitions,
        // not a blank gap.
        const ytCard = document.getElementById('ytCard');
        if (ytCard) {
          ytCard.hidden = false;
          // Show all skeleton placeholders
          document.getElementById('ytCardThumbWrap').classList.remove('is-loaded');
          document.getElementById('ytCardThumbSkeleton').classList.remove('is-hidden');
          document.getElementById('ytCardTitleSkeleton').classList.remove('is-hidden');
          document.getElementById('ytCardDurationSkeleton').classList.remove('is-hidden');
          // Clear old content
          document.getElementById('ytCardThumb').src = '';
          document.getElementById('ytCardTitle').textContent = '';
          document.getElementById('ytCardTitle').classList.add('yt-card-title--empty');
          document.getElementById('ytCardDuration').textContent = '';
          document.getElementById('ytCardDuration').classList.add('yt-card-duration--empty');
        }
        // Pause the processing timer (don't count gap between videos)
        pauseTimer();
        // Show steps "Starting..." overlay for new video
        const stepsOverlay = document.getElementById('procStepsOverlay');
        if (stepsOverlay) stepsOverlay.classList.remove('is-hidden');
        overlayHidden = false;
      }
      lastPlaylistCompleted = completed;
      updatePlaylistUI(playlist_info);
    }

    if (stages) {
      applySnapshotStages(stages);
    }

    patchAllSteps();

    if (stage === "complete") {
      STAGES.forEach((s) => {
        stageState[s.id].status = "done";
        stageState[s.id].progress = 100;
        stageState[s.id].message = "Done";
      });
      patchAllSteps();
      if (eventSource) eventSource.close();
      if (pollInterval) clearInterval(pollInterval);
      if (timerInterval) clearInterval(timerInterval);
      setTimeout(() => {
        window.location.href = `/result/${jobId}`;
      }, 700);
    }

    if (stage === "error") {
      const active = STAGES.find((s) => stageState[s.id].status === "active");
      if (active) {
        stageState[active.id].status = "error";
        stageState[active.id].message = message || "Failed";
        patchStepDOM(active.id);
      }
      if (eventSource) eventSource.close();
      if (pollInterval) clearInterval(pollInterval);
      if (timerInterval) clearInterval(timerInterval);
      setTimeout(() => {
        window.location.href = `/error?error=${encodeURIComponent(message || "Processing failed")}&job_id=${jobId}`;
      }, 1200);
    }

    // Show toast when autosave completes (files saved to Google Drive on Colab)
    if (stage === "autosave" && stages?.autosave?.status === "done") {
      if (typeof window.showToast === "function" && pageData.is_colab) {
        window.showToast("Files saved to Google Drive", "ok");
      }
    }

    if (stage === "cancelled") {
      if (eventSource) eventSource.close();
      if (pollInterval) clearInterval(pollInterval);
      if (timerInterval) clearInterval(timerInterval);
      window.location.href = '/cancelled';
    }
  }

  function pollStatus() {
    fetch(`/status/${jobId}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.deduplication_enabled !== undefined) {
          pageData.deduplication_enabled = data.deduplication_enabled;
        }
        if (data.progress) {
          applyProgress(data.progress, data.deduplication_enabled);
        }
        if (data.status === "completed") {
          window.location.href = `/result/${jobId}`;
        }
        if (data.status === "cancelled") {
          window.location.href = '/cancelled';
        }
      })
      .catch(() => {});
  }

  window.cancelProcessing = async function () {
    const confirmed = await showConfirmDialog('Cancel processing?', 'Your progress will be lost and you will need to start over.');
    if (!confirmed) return;
    
    // Close SSE and polling immediately so the UI stops updating
    if (eventSource) { eventSource.close(); eventSource = null; }
    if (pollInterval) { clearInterval(pollInterval); pollInterval = null; }
    
    const btn = document.getElementById("cancel-btn");
    btn.disabled = true;
    btn.textContent = "Cancelling…";
    
    // Fire cancel request but don't wait — redirect right away.
    // Use sendBeacon so the request reliably completes even during page navigation.
    navigator.sendBeacon(`/cancel/${jobId}`);
    window.location.href = '/cancelled';
  };

  function formatElapsed(ms) {
    const totalSec = Math.floor(ms / 1000);
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return `${min}:${sec.toString().padStart(2, '0')}`;
  }

  function updateTimer() {
    if (!timerStarted) return;
    const el = document.getElementById('procTimer');
    if (!el) return;
    const totalMs = timerAccumulated + (Date.now() - timerStart);
    el.textContent = formatElapsed(totalMs);
  }

  setPageTitle();
  // Don't show playlist counter yet — wait until card data renders
  // so it appears alongside the YouTube card info.
  // Keep it hidden initially by not removing the hidden attribute.
  if (isPlaylist) {
    document.getElementById("playlistCompleted").textContent = "1";
    if (pageData.playlist_total > 1) {
      document.getElementById("playlistTotal").textContent = pageData.playlist_total;
    }
  } else {
    hidePlaylistUI();
  }

  const initStages = pageData.initial_progress?.stages;
  setStagesLayout(
    resolveShowDedup(pageData.deduplication_enabled, initStages),
    initStages
  );

  if (pageData.initial_progress) {
    applyProgress(pageData.initial_progress, pageData.deduplication_enabled);
    lastPayload = "";
  }

  // Defer first poll AND SSE connection by one frame so the browser paints the
  // initial "Starting..." overlay before any progress event can hide it.
  // Without this, the SSE first event (which yields the current backend state)
  // arrives before paint, hiding the overlay immediately if the backend has
  // already progressed past 'initializing' (which it often has).
  requestAnimationFrame(function () {
    pollStatus();
    pollInterval = setInterval(pollStatus, 600);

    eventSource = new EventSource(`/progress/${jobId}`);
    eventSource.onmessage = (e) => {
      try {
        applyProgress(JSON.parse(e.data));
      } catch (err) {
        console.error(err);
      }
    };
    eventSource.onerror = () => {
      if (eventSource) {
        eventSource.close();
        eventSource = null;
      }
    };
  });
})();
