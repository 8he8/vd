"""
Frame extraction module using ffmpeg.
Extracted from the original Colab notebook.
"""

import os
import re
import subprocess
import threading
import time
import logging
from config import resolve_ffmpeg
from .youtube_downloader import format_youtube_time
from .job_runtime import is_cancelled, register_process

logger = logging.getLogger(__name__)

_FFMPEG_TIME_RE = re.compile(r'time=(\d+):(\d+):(\d+(?:\.\d+)?)')


def _count_extracted_frames(output_folder):
    if not os.path.isdir(output_folder):
        return 0
    return len([
        f for f in os.listdir(output_folder)
        if f.startswith('frame_') and f.endswith('.jpg')
    ])


def _run_ffmpeg_with_progress(cmd, output_folder, duration, progress_callback=None, estimated_frames=None, job_id=None, stderr_collector=None):
    """Run ffmpeg and report progress via stderr time= and frame folder polling."""
    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding='utf-8',
        errors='replace',
    )
    if job_id:
        register_process(job_id, process)
        # Also register under the parent job_id so that cancelling the main
        # playlist job terminates this subprocess even though it runs under a
        # sub_job_id (e.g. "{parent}_video_1").
        parent_id = job_id.rsplit('_video_', 1)[0] if '_video_' in job_id else None
        if parent_id:
            register_process(parent_id, process)

    # Shared mutable for latest frame count: poll thread writes, stderr parser reads.
    latest_frame_count = [0]
    max_time_seen = [0.0]
    max_count_seen = [0]

    stop_poll = threading.Event()

    def poll_folder():
        while not stop_poll.is_set():
            if job_id and is_cancelled(job_id):
                break
            count = _count_extracted_frames(output_folder)
            # Monotonic frame count — never report fewer frames than before
            if count > max_count_seen[0]:
                max_count_seen[0] = count
            latest_frame_count[0] = max_count_seen[0]
            time.sleep(0.35)

    poll_thread = threading.Thread(target=poll_folder, daemon=True)
    if progress_callback:
        poll_thread.start()

    stderr_lines = []
    cancelled = False
    try:
        for line in process.stderr:
            if job_id and is_cancelled(job_id):
                cancelled = True
                break
            logger.info(f"FFmpeg: {line.strip()}")
            stderr_lines.append(line)
            if stderr_collector is not None:
                stderr_collector.append(line)
            if progress_callback and duration > 0:
                match = _FFMPEG_TIME_RE.search(line)
                if match:
                    h, m, s = match.groups()
                    current_sec = int(h) * 3600 + int(m) * 60 + float(s)
                    # Monotonic time — guard against ffmpeg reporting non-monotonic timestamps
                    if current_sec > max_time_seen[0]:
                        max_time_seen[0] = current_sec
                    pct = min(99, int(max_time_seen[0] / duration * 100))
                    count = latest_frame_count[0]
                    progress_callback(
                        count,
                        estimated_frames or max(1, int(duration)),
                        pct,
                    )
        if cancelled:
            process.terminate()
            process.wait(timeout=5)
            return
        process.wait()
        if process.returncode != 0:
            raise subprocess.CalledProcessError(
                process.returncode, cmd, stderr=''.join(stderr_lines)
            )
    finally:
        stop_poll.set()
        poll_thread.join(timeout=1)
        if process.poll() is None:
            process.terminate()
            process.wait()


def _ffmpeg_cmd_base():
    ffmpeg_bin = resolve_ffmpeg()
    if not ffmpeg_bin:
        return None
    return ffmpeg_bin


def extract_frames_time_interval(video_source, output_folder, interval_seconds=5, duration=0, fps=25, frame_quality=2, progress_callback=None, job_id=None):
    """Extract frames at fixed time intervals using ffmpeg."""
    logger.info("\n" + "=" * 70 + "\nEXTRACTING FRAMES - TIME INTERVAL METHOD\n" + "=" * 70)
    logger.info("INFO: Real-time FFmpeg logs enabled.")

    os.makedirs(output_folder, exist_ok=True)

    ffmpeg_bin = _ffmpeg_cmd_base()
    if not ffmpeg_bin:
        logger.error(
            "FFmpeg not found. Install FFmpeg and add it to PATH "
            "(Windows: winget install Gyan.FFmpeg, then restart the terminal)."
        )
        return []

    if job_id and is_cancelled(job_id):
        return []

    if duration == 0 or fps == 0:
        logger.error("Error: Could not determine video duration or FPS. Skipping frame extraction.")
        logger.info("=" * 70)
        return []

    total_duration_formatted = format_youtube_time(int(duration))
    logger.info(f"Video Duration: {int(duration)//60}m {int(duration)%60}s ({total_duration_formatted})")
    logger.info(f"Video FPS: {fps:.2f}")
    logger.info(f"Interval: {interval_seconds}s")
    logger.info(f"Frame JPEG Quality: {frame_quality} (1=best, 31=worst)")

    cmd = [
        ffmpeg_bin,
        '-an', '-sn',
        '-i', video_source,
        '-vsync', '0',
        '-q:v', str(frame_quality),
        '-vf', f"fps=1/{interval_seconds}",
        '-threads', '0',
        '-preset', 'ultrafast',
        '-loglevel', 'info',
        os.path.join(output_folder, 'frame_%06d.jpg')
    ]

    estimated_frames = max(1, int(duration / interval_seconds)) if interval_seconds > 0 else None
    logger.info(f"Starting FFmpeg process: {' '.join(cmd)}")
    try:
        _run_ffmpeg_with_progress(
            cmd, output_folder, duration, progress_callback, estimated_frames, job_id=job_id
        )
    except subprocess.CalledProcessError as e:
        logger.error(f"Error: FFmpeg frame extraction failed. Return code: {e.returncode}")
        logger.error(f"Stderr: {e.stderr}")
        return []
    except FileNotFoundError:
        logger.error("FFmpeg executable not found. Install FFmpeg and restart the app.")
        return []
    except Exception as e:
        if job_id and is_cancelled(job_id):
            logger.info("Frame extraction cancelled")
            return []
        logger.error(f"An unexpected error occurred during FFmpeg: {e}")
        return []

    if not os.path.exists(output_folder) or not os.path.isdir(output_folder):
        logger.error(f"Error: Output folder does not exist or is not a directory: {output_folder}")
        logger.info("=" * 70)
        return []

    extracted_frames = sorted(
        [
            os.path.join(output_folder, f)
            for f in os.listdir(output_folder)
            if f.startswith('frame_') and f.endswith('.jpg')
        ],
        key=lambda x: int(os.path.basename(x).split('_')[1].split('.')[0])
    )
    logger.info(f"\nExtracted {len(extracted_frames)} frames.")
    logger.info("=" * 70)

    if progress_callback:
        total = estimated_frames or len(extracted_frames)
        progress_callback(len(extracted_frames), total, 100)

    return extracted_frames


def extract_frames_scene_detection(video_source, output_folder, ssim_threshold=0.8, duration=0, fps=25, frame_quality=2, progress_callback=None, job_id=None):
    """Extract frames using scene detection (standard full-resolution mode).

    Returns:
        Tuple of (frame_paths, pts_times_or_None)
        - frame_paths: list of paths to extracted frame images
        - pts_times_or_None: list of exact PTS timestamps (float seconds) for each frame,
                             or None if timestamps could not be determined
    """
    logger.info("\n" + "=" * 70 + "\nEXTRACTING FRAMES - SCENE DETECTION (STANDARD FULL RES)\n" + "=" * 70)

    os.makedirs(output_folder, exist_ok=True)

    ffmpeg_bin = _ffmpeg_cmd_base()
    if not ffmpeg_bin:
        logger.error(
            "FFmpeg not found. Install FFmpeg and add it to PATH "
            "(Windows: winget install Gyan.FFmpeg, then restart the terminal)."
        )
        return [], None

    if job_id and is_cancelled(job_id):
        return [], None

    if duration == 0 or fps == 0:
        logger.error("Error: Could not determine video duration or FPS. Skipping frame extraction.")
        logger.info("=" * 70)
        return [], None

    total_duration_formatted = format_youtube_time(int(duration))
    logger.info(f"INFO: Video Duration: {int(duration)//60}m {int(duration)%60}s ({total_duration_formatted})")
    logger.info(f"INFO: Video FPS: {fps:.2f}")
    logger.info(f"INFO: Frame JPEG Quality: {frame_quality} (1=best, 31=worst)")

    scene_threshold_ffmpeg = max(0.01, min(0.99, 1 - ssim_threshold))

    # ── STANDARD MODE: Single-pass full-resolution scene detection + extraction ──
    # showinfo filter outputs PTS of each selected frame to stderr, which we
    # parse to get exact timestamps for each extracted frame.
    cmd = [
        ffmpeg_bin,
        '-an', '-sn',
        '-i', video_source,
        '-vsync', 'vfr',
        '-q:v', str(frame_quality),
        '-f', 'image2',
        # NOTE: +not(n) instead of ||eq(n,0) to include first frame.
        # || breaks ffmpeg on Windows; NOT() uses wrong case (lowercase is correct).
        # + works as logical OR since gt() and not() return 0/1.
        '-vf', f"select='gt(scene,{scene_threshold_ffmpeg})+not(n)',showinfo",
        '-threads', '0',
        '-preset', 'ultrafast',
        '-loglevel', 'info',
        os.path.join(output_folder, 'frame_%06d.jpg')
    ]

    logger.info("Running single-pass full-resolution scene detection + extraction...")
    logger.debug(f"  cmd: {' '.join(cmd)}")

    # Collect stderr lines so we can parse showinfo PTS timestamps
    stderr_collector = []
    est_frames = max(1, int(duration / 2))
    try:
        _run_ffmpeg_with_progress(
            cmd, output_folder, duration, progress_callback, est_frames, job_id=job_id,
            stderr_collector=stderr_collector,
        )
    except subprocess.CalledProcessError as e:
        logger.error(f"Error: FFmpeg frame extraction failed. Return code: {e.returncode}")
        logger.error(f"Stderr: {e.stderr}")
        return [], None
    except FileNotFoundError:
        logger.error("FFmpeg executable not found. Install FFmpeg and restart the app.")
        return [], None
    except Exception as e:
        if job_id and is_cancelled(job_id):
            logger.info("Frame extraction cancelled")
            return [], None
        logger.error(f"An unexpected error occurred during FFmpeg: {e}")
        return [], None

    if not os.path.exists(output_folder) or not os.path.isdir(output_folder):
        logger.error(f"Error: Output folder does not exist or is not a directory: {output_folder}")
        logger.info("=" * 70)
        return [], None

    frame_files = sorted(
        [
            os.path.join(output_folder, f)
            for f in os.listdir(output_folder)
            if f.startswith('frame_') and f.endswith('.jpg')
        ],
        key=lambda x: int(os.path.basename(x).split('_')[1].split('.')[0])
    )
    logger.info(f"\nExtracted {len(frame_files)} frames.")
    logger.info("=" * 70)

    if progress_callback:
        total = est_frames or len(frame_files)
        progress_callback(len(frame_files), total, 100)

    # ── Parse exact PTS timestamps from showinfo output ──────────────────
    # showinfo prints "pts_time:X.XXX" for each frame that passes the select filter.
    # These appear in stderr in the same order as the output frame files.
    pts_re = re.compile(r'pts_time:(\d+(?:\.\d+)?)')
    raw_pts = []
    for line in stderr_collector:
        m = pts_re.search(line)
        if m:
            raw_pts.append(float(m.group(1)))

    # Only return exact timestamps if count matches output frames
    pts_times = raw_pts if len(raw_pts) == len(frame_files) else None
    if pts_times:
        logger.info(f"Captured {len(pts_times)} exact PTS timestamps from ffmpeg showinfo")
        for i, fp in enumerate(frame_files[:5]):
            logger.info(f"  {os.path.basename(fp)} @ {pts_times[i]:.3f}s")
        if len(frame_files) > 5:
            logger.info(f"  ... and {len(frame_files) - 5} more")
    else:
        logger.warning(f"PTS timestamp count ({len(raw_pts)}) doesn't match frame count ({len(frame_files)}). "
                       "Falling back to linear interpolation for timestamps.")

    return frame_files, pts_times
