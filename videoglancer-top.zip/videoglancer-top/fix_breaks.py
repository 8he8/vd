import json

path = r'C:\Users\Hammad\Desktop\Code\videoglancer-top\videoglancer-top.ipynb'

with open(path, 'r', encoding='utf-8') as f:
    nb = json.load(f)

cell5 = nb['cells'][5]
src5 = cell5['source']

# Find the 3 lines: print(), print(), print('=' * 70)
# after "Just run all 3 blocks again"
# Move the 2 print() after the = line

for i, line in enumerate(src5):
    if "print('  Just run all 3 blocks again')" in line:
        if i + 3 < len(src5):
            l1 = src5[i+1]
            l2 = src5[i+2]
            l3 = src5[i+3]
            is_print1 = l1.strip() == 'print()'
            is_print2 = l2.strip() == 'print()'
            is_eq = "'=' * 70" in l3
            if is_print1 and is_print2 and is_eq:
                # Reorder: keep "Just run..." at i, put = at i+1, put print() at i+2, i+3
                src5[i+1] = l3
                src5[i+2] = l1
                src5[i+3] = l2
                print("Moved 2 blank lines after === divider")
                break
        break

with open(path, 'w', encoding='utf-8') as f:
    json.dump(nb, f, indent=1, ensure_ascii=False)

print("Done!")
