"""
Configuration file for Videoglancer Flask application.
Centralizes all paths, settings, and configuration values.
"""

import os

# Base directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Check if running in Google Colab (Drive mount is optional, so check for the Colab runtime itself)
try:
    import google.colab  # noqa: F401
    IS_COLAB = True
except ImportError:
    IS_COLAB = False

# Directory paths
if IS_COLAB:
    WORK_DIR = os.path.join(BASE_DIR, "temp")
    FRAMES_DIR = os.path.join(BASE_DIR, "temp", "frames")
    TEMP_DOWNLOAD_DIR = os.path.join(BASE_DIR, "temp", "downloads")
else:
    WORK_DIR = os.path.join(BASE_DIR, "temp")
    FRAMES_DIR = os.path.join(BASE_DIR, "temp", "frames")
    TEMP_DOWNLOAD_DIR = os.path.join(BASE_DIR, "temp", "downloads")

OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")

# Google Drive output path (Colab only — used for copying, not as primary OUTPUT_DIR)
DRIVE_DIR = '/content/drive/MyDrive/Videoglancer.top'
DRIVE_MOUNT_CHECK = '/content/drive/MyDrive'


def is_drive_mounted():
    """Check if Google Drive is actually mounted in Colab (not just the runtime detected)."""
    if not IS_COLAB:
        return False
    try:
        return os.path.isdir(DRIVE_MOUNT_CHECK)
    except OSError:
        return False

# Internal data directory (always local, never on Drive — used for outputs_meta.json)
DATA_DIR = os.path.join(BASE_DIR, "data")

# Frame quality settings
DEFAULT_FONT_SIZE_RATIO = 0.025
MIN_FONT_SIZE_PX = 16

# Deduplication thresholds
DEFAULT_PHASH_THRESHOLD = 7
DEFAULT_SSIM_THRESHOLD = 0.97

# Default extraction method settings
DEFAULT_SCENE_THRESHOLD = 0.8
DEFAULT_TIME_INTERVAL = 5.0

# FFmpeg settings
FFMPEG_THREADS = 0
FFMPEG_PRESET = 'ultrafast'

# Player clients tried in order when YouTube returns bot/sign-in errors
YOUTUBE_PLAYER_CLIENT_FALLBACKS = [
    ['android', 'ios'],
    ['android', 'web'],
    ['ios', 'mweb'],
    ['mweb', 'android'],
    ['tv', 'tv_embedded'],
    ['web'],
]

YDL_HTTP_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-us,en;q=0.5',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Site': 'none',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-ch-ua': '"Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
}


CONCURRENT_DOWNLOADS = 32

# Flask settings
SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max upload

# Info page settings
INFO_PAGE_WIDTH = 1280
INFO_PAGE_HEIGHT = 720

# Colors for info page
INFO_PAGE_COLORS = {
    'BG_COLOR': (15, 15, 15),
    'CARD_COLOR': (24, 24, 24),
    'ACCENT_RED': (255, 0, 0),
    'TEXT_WHITE': (255, 255, 255),
    'TEXT_GREY': (170, 170, 170),
    'TEXT_LIGHT_GREY': (120, 120, 120),
    'DIVIDER_COLOR': (40, 40, 40),
    'BADGE_BG': (33, 33, 33),
    'PROMO_BG': (20, 20, 20)
}

# Font paths (Linux/Colab and Windows)
FONT_PATHS = {
    'bold': [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/ubuntu/Ubuntu-B.ttf",
        # Windows fonts
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'ARIALBD.TTF'),
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'arial.ttf'),
        os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'Fonts', 'Roboto-Bold.ttf'),
        os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'Fonts', 'Roboto-Medium.ttf'),
    ],
    'regular': [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/ubuntu/Ubuntu-R.ttf",
        # Windows fonts
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'arial.ttf'),
        os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'Fonts', 'Roboto-Regular.ttf'),
    ],
    'mono_bold': [
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationMono-Bold.ttf",
        "/usr/share/fonts/truetype/ubuntu/UbuntuMono-B.ttf",
        # Windows fonts
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'cour.ttf'),
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'courbd.ttf'),
    ],
    'wide_coverage': [
        # Windows CJK fonts (Japanese, Chinese, Korean)
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'msgothic.ttc'),  # MS Gothic (JP)
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'meiryo.ttc'),    # Meiryo (JP)
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'malgun.ttf'),    # Malgun Gothic (KR)
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'simhei.ttf'),    # SimHei (CN)
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'simsun.ttc'),    # SimSun (CN)
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'mingliu.ttc'),   # MingLiU (TW)
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'segoeui.ttf'),   # Segoe UI (wide Unicode)
        os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'seguisb.ttf'),   # Segoe UI Semibold
        os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'Fonts', 'NotoSansSC-Regular.ttf'),
        os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'Fonts', 'NotoSansJP-Regular.otf'),
        os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'Fonts', 'NotoSansKR-Regular.otf'),
        # Linux fallbacks
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
    ]
}

# FFmpeg (required for frame extraction)
_FFMPEG_PATH = None


def resolve_ffmpeg():
    """Return path to ffmpeg binary, searching PATH and common Windows install locations."""
    global _FFMPEG_PATH
    if _FFMPEG_PATH and os.path.isfile(_FFMPEG_PATH):
        return _FFMPEG_PATH

    import shutil
    import glob

    found = shutil.which('ffmpeg')
    if found and os.path.isfile(found):
        _FFMPEG_PATH = found
        return _FFMPEG_PATH

    if os.name == 'nt':
        candidates = []
        local_app = os.environ.get('LOCALAPPDATA', '')
        if local_app:
            # Check WinGet installation directories
            candidates.extend(glob.glob(
                os.path.join(local_app, 'Microsoft', 'WinGet', 'Packages', '*FFmpeg*', '**', 'ffmpeg.exe'),
                recursive=True,
            ))
            candidates.append(os.path.join(local_app, 'Microsoft', 'WinGet', 'Links', 'ffmpeg.exe'))
        program_files = os.environ.get('ProgramFiles', r'C:\Program Files')
        candidates.extend([
            os.path.join(program_files, 'ffmpeg', 'bin', 'ffmpeg.exe'),
            r'C:\ffmpeg\bin\ffmpeg.exe',
        ])
        for path in candidates:
            if path and os.path.isfile(path):
                _FFMPEG_PATH = path
                return _FFMPEG_PATH
        # Also check WinGet versioned directory (e.g., ffmpeg-8.1.1-full_build)
        if local_app:
            winget_base = os.path.join(local_app, 'Microsoft', 'WinGet', 'Packages')
            if os.path.exists(winget_base):
                for pkg in os.listdir(winget_base):
                    if 'FFmpeg' in pkg:
                        for entry in os.listdir(os.path.join(winget_base, pkg)):
                            if entry.startswith('ffmpeg-') and os.path.isdir(os.path.join(winget_base, pkg, entry)):
                                ffmpeg_bin = os.path.join(winget_base, pkg, entry, 'bin', 'ffmpeg.exe')
                                if os.path.isfile(ffmpeg_bin):
                                    _FFMPEG_PATH = ffmpeg_bin
                                    return _FFMPEG_PATH

    return None


def ffmpeg_available():
    return resolve_ffmpeg() is not None


def build_ydl_opts(player_clients=None, **overrides):
    """Build yt-dlp options.

    By default (player_clients=None), yt-dlp uses its own client defaults
    which includes android_vr — this returns progressive DASH video-only
    formats with stable file sizes and no PO token requirement.
    Pass player_clients to override (used by the fallback mechanism when
    the default triggers a bot/403 error during extraction).
    """
    opts = {
        'noplaylist': True,
        'quiet': False,
        'no_warnings': False,
        'nocheckcertificate': True,
        'geo_bypass': True,
        'socket_timeout': 15 if IS_COLAB else 30,
        'retries': 15,
        'fragment_retries': 15,
        'ignoreerrors': False,
        'ignore_fragments': True,
        'remote_components': ['ejs:github'],
        'http_headers': YDL_HTTP_HEADERS.copy(),
    }

    if player_clients:
        opts['extractor_args'] = {
            'youtube': {'player_client': player_clients},
        }

    ffmpeg_path = resolve_ffmpeg()
    if ffmpeg_path:
        opts['ffmpeg_location'] = ffmpeg_path
    opts.update(overrides)
    return opts


# Default options used across the app
YDL_COMMON_OPTS = build_ydl_opts()


# Ensure directories exist
def ensure_directories():
    """Create all necessary directories if they don't exist."""
    directories = [
        WORK_DIR,
        OUTPUT_DIR,
        FRAMES_DIR,
        TEMP_DOWNLOAD_DIR,
        DATA_DIR
    ]
    for directory in directories:
        os.makedirs(directory, exist_ok=True)

# Initialize directories on import
ensure_directories()
